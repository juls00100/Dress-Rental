/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c_Staff;

import b_Admin.*;
import a_Main.landingpage;
import a_Main.login;
import config.config;
import config.session;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author juls
 */
public class alldress extends javax.swing.JFrame {

    /**
     * Creates new form alldress
     */
    public alldress() {
        initComponents();
           dressContainerPanel.setLayout(new java.awt.FlowLayout(
    FlowLayout.LEFT, 10, 10 // left-align, 10px horizontal & vertical gap
));

        loadDresses(); 
          session sess = session.getInstance();
          
        
        
    }
    
   private void loadDresses() {
    dressContainerPanel.removeAll(); // clear old items

    try {
        config db = new config();
        ResultSet rs = db.getData("SELECT * FROM dress_tbl");

        while (rs.next()) {

            JPanel card = new JPanel();
            card.setPreferredSize(new Dimension(150, 240)); // slightly taller to fit button
            card.setBackground(Color.WHITE);
            card.setBorder(BorderFactory.createLineBorder(Color.PINK));
            card.setLayout(new java.awt.BorderLayout());

            // ⭐ IMAGE
            String imagePath = rs.getString("dress_image");
            JLabel imageLabel = new JLabel();
            imageLabel.setPreferredSize(new Dimension(150, 120));

            if (imagePath != null && !imagePath.isEmpty()) {
                ImageIcon icon = new ImageIcon(imagePath);
                Image img = icon.getImage().getScaledInstance(
                        150, 120, java.awt.Image.SCALE_SMOOTH
                );
                imageLabel.setIcon(new ImageIcon(img));
            }

            // ⭐ INFO PANEL
           // 2. INFO & ACTION PANEL
            JPanel infoPanel = new JPanel();
            infoPanel.setBackground(Color.WHITE);
            infoPanel.setLayout(new java.awt.GridLayout(4, 1)); // 4 rows: Name, Price, Status, Button

            String dName = rs.getString("dress_name");
            String dPrice = rs.getString("dress_price");
            String dStatus = rs.getString("dress_status"); // Get the status from DB
            String dId = rs.getString("dress_id");

            JLabel nameLabel = new JLabel(dName, JLabel.CENTER);
            JLabel priceLabel = new JLabel("₱ " + dPrice, JLabel.CENTER);
            
            // STATUS LABEL (Color coded)
            JLabel statusLabel = new JLabel(dStatus, JLabel.CENTER);
            statusLabel.setFont(new java.awt.Font("Tahoma", 1, 10));
            
            // ACTION BUTTON
            javax.swing.JButton rentButton = new javax.swing.JButton();
            rentButton.setForeground(Color.WHITE);

            // LOGIC: Check if Available or Rented
            if ("Available".equalsIgnoreCase(dStatus)) {
                statusLabel.setForeground(new Color(0, 153, 51)); // Green for Available
                rentButton.setText("Mark as Rented");
                rentButton.setBackground(new Color(255, 102, 153)); // Pink
                rentButton.setEnabled(true);
            } else {
                statusLabel.setForeground(Color.RED); // Red for Rented
                rentButton.setText("Not Available");
                rentButton.setBackground(Color.GRAY);
                rentButton.setEnabled(false); // Disable button if already rented
            };


            // Action Listener
            double dPriceVal = rs.getDouble("dress_price");
            rentButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    rentprocess rent = new rentprocess(dId, dName, dPriceVal);
                    rent.setVisible(true);
                    alldress.this.dispose();
                }
            });


            infoPanel.add(nameLabel);
            infoPanel.add(priceLabel);
            infoPanel.add(statusLabel);
            infoPanel.add(rentButton);

            card.add(imageLabel, java.awt.BorderLayout.CENTER);
            card.add(infoPanel, java.awt.BorderLayout.SOUTH);

            dressContainerPanel.add(card);
        }

        dressContainerPanel.revalidate();
        dressContainerPanel.repaint();

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error loading dresses: " + e.getMessage());
    }

}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        dressContainerPanel = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        managepay = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        logout = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        managerent = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        managedress = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        home = new javax.swing.JPanel();
        dashboard = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        managepay1 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 209, 220));
        jPanel2.setPreferredSize(new java.awt.Dimension(360, 480));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 51, 153));
        jLabel2.setText("Staff Dashboard  ");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, -1, 20));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/DressRent__6_-removebg-preview.png"))); // NOI18N
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-160, 0, 220, 190));

        dressContainerPanel.setBackground(new java.awt.Color(255, 209, 220));
        dressContainerPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel2.add(dressContainerPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 60, 560, 420));

        jPanel10.setBackground(new java.awt.Color(255, 235, 239));
        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        managepay.setBackground(new java.awt.Color(255, 183, 201));
        managepay.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                managepayMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                managepayMouseExited(evt);
            }
        });
        managepay.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setFont(new java.awt.Font("Georgia", 1, 16)); // NOI18N
        jLabel6.setText("Profile");
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });
        managepay.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, -1, -1));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/payments.png"))); // NOI18N
        managepay.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 40, 40));

        jPanel10.add(managepay, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 150, 40));

        logout.setBackground(new java.awt.Color(165, 42, 42));
        logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                logoutMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                logoutMouseExited(evt);
            }
        });
        logout.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Georgia", 1, 16)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(240, 240, 240));
        jLabel7.setText("Back");
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });
        logout.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 9, -1, 20));

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/logout-removebg-preview (1).png"))); // NOI18N
        logout.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jPanel10.add(logout, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, 150, 40));

        managerent.setBackground(new java.awt.Color(255, 183, 201));
        managerent.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                managerentMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                managerentMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                managerentMouseExited(evt);
            }
        });
        managerent.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel34.setFont(new java.awt.Font("Georgia", 1, 16)); // NOI18N
        jLabel34.setText("Customers");
        jLabel34.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel34MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel34MouseEntered(evt);
            }
        });
        managerent.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, -1, -1));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/dressRent-removebg-preview.png"))); // NOI18N
        managerent.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 40, 40));

        jPanel10.add(managerent, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 150, 40));

        managedress.setBackground(new java.awt.Color(255, 209, 220));
        managedress.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                managedressMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                managedressMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                managedressMouseExited(evt);
            }
        });
        managedress.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Georgia", 1, 16)); // NOI18N
        jLabel10.setText("Dress");
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });
        managedress.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 60, -1));

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/manangedress-removebg-preview.png"))); // NOI18N
        managedress.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 40, 40));

        jPanel10.add(managedress, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 160, 40));

        home.setBackground(new java.awt.Color(255, 183, 201));
        home.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                homeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                homeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                homeMouseExited(evt);
            }
        });
        home.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        dashboard.setFont(new java.awt.Font("Georgia", 1, 16)); // NOI18N
        dashboard.setText("Dashboard");
        dashboard.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dashboardMouseClicked(evt);
            }
        });
        home.add(dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 0, 100, 40));

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/home-removebg-preview.png"))); // NOI18N
        home.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jPanel10.add(home, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 150, 40));

        managepay1.setBackground(new java.awt.Color(255, 183, 201));
        managepay1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                managepay1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                managepay1MouseExited(evt);
            }
        });
        managepay1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Georgia", 1, 16)); // NOI18N
        jLabel8.setText("Rent");
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });
        managepay1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, -1, -1));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/payments.png"))); // NOI18N
        managepay1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 40, 40));

        jPanel10.add(managepay1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 150, 40));

        jPanel2.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 170, 420));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 740, 480));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        userprofile pay = new userprofile();
        pay.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel6MouseClicked

    private void managepayMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_managepayMouseEntered
        // managepay.setBackground(new Color (255,255,255));
    }//GEN-LAST:event_managepayMouseEntered

    private void managepayMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_managepayMouseExited
        // managepay.setBackground(new Color (255,153,255));
    }//GEN-LAST:event_managepayMouseExited

    private void logoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMouseClicked
        staff_dashboard land = new staff_dashboard();
        land.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_logoutMouseClicked

    private void logoutMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMouseEntered
        // logout.setBackground(new Color (255,255,255));
    }//GEN-LAST:event_logoutMouseEntered

    private void logoutMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMouseExited
        //logout.setBackground(new Color (255,153,255));
    }//GEN-LAST:event_logoutMouseExited

    private void jLabel34MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel34MouseClicked

    }//GEN-LAST:event_jLabel34MouseClicked

    private void jLabel34MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel34MouseEntered

    }//GEN-LAST:event_jLabel34MouseEntered

    private void managerentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_managerentMouseClicked
        //transtable table = new transtable();
        // table.setVisible(true);
        //this.dispose();
    }//GEN-LAST:event_managerentMouseClicked

    private void managerentMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_managerentMouseEntered
        //managerent.setBackground(new Color (255,255,255));
    }//GEN-LAST:event_managerentMouseEntered

    private void managerentMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_managerentMouseExited
        // managerent.setBackground(new Color (255,153,255));
    }//GEN-LAST:event_managerentMouseExited

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        alldress dress = new alldress();
        dress.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel10MouseClicked

    private void managedressMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_managedressMouseClicked
        //adddress dress = new adddress();
        //dress.setVisible(true);
        //this.dispose();
    }//GEN-LAST:event_managedressMouseClicked

    private void managedressMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_managedressMouseEntered
        //managedress.setBackground(new Color (255,255,255));
    }//GEN-LAST:event_managedressMouseEntered

    private void managedressMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_managedressMouseExited
        // managedress.setBackground(new Color (255,153,255));
    }//GEN-LAST:event_managedressMouseExited

    private void dashboardMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashboardMouseClicked
        staff_dashboard dash = new staff_dashboard();
        dash.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_dashboardMouseClicked

    private void homeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseClicked
        staff_dashboard dash = new staff_dashboard();
        dash.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_homeMouseClicked

    private void homeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseEntered
        //  home.setBackground(new Color (255,255,255));
    }//GEN-LAST:event_homeMouseEntered

    private void homeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseExited
        //home.setBackground(new Color (255,153,255));
    }//GEN-LAST:event_homeMouseExited

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
        rentprocess dash = new rentprocess();
        dash.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel8MouseClicked

    private void managepay1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_managepay1MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_managepay1MouseEntered

    private void managepay1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_managepay1MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_managepay1MouseExited

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        staff_dashboard dash = new staff_dashboard();
        dash.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel7MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(alldress.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(alldress.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(alldress.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(alldress.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new alldress().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel dashboard;
    private javax.swing.JPanel dressContainerPanel;
    private javax.swing.JPanel home;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel logout;
    private javax.swing.JPanel managedress;
    private javax.swing.JPanel managepay;
    private javax.swing.JPanel managepay1;
    private javax.swing.JPanel managerent;
    // End of variables declaration//GEN-END:variables
}
